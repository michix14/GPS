<!-- resources/views/gps/show.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>View GPS Data</title>
</head>
<body>
    <h1>View GPS Data</h1>
    <p><strong>ID:</strong> <?php echo e($gps->id); ?></p>
    <p><strong>Latitude:</strong> <?php echo e($gps->latitude); ?></p>
    <p><strong>Longitude:</strong> <?php echo e($gps->longitude); ?></p>
    <p><strong>Placa:</strong> <?php echo e($gps->placa); ?></p>
    <p><strong>Suben:</strong> <?php echo e($gps->suben); ?></p>
    <p><strong>Bajan:</strong> <?php echo e($gps->bajan); ?></p>
    <p><strong>Linea:</strong> <?php echo e($gps->linea); ?></p>
    <a href="<?php echo e(route('gps.index')); ?>">Back</a>
</body>
</html>
<?php /**PATH C:\Users\HP\OneDrive\Desktop\gps\resources\views/gps/show.blade.php ENDPATH**/ ?>