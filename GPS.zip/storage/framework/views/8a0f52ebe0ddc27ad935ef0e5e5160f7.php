<!-- resources/views/gps/edit.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Edit GPS Data</title>
</head>
<body>
    <h1>Edit GPS Data</h1>
    <form action="<?php echo e(route('gps.update', $gps->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label>Latitude:</label>
        <input type="text" name="latitude" value="<?php echo e($gps->latitude); ?>"><br><br>
        <label>Longitude:</label>
        <input type="text" name="longitude" value="<?php echo e($gps->longitude); ?>"><br><br>
        <label>Placa:</label>
        <input type="text" name="placa" value="<?php echo e($gps->placa); ?>"><br><br>
        <label>Suben:</label>
        <input type="number" name="suben" value="<?php echo e($gps->suben); ?>"><br><br>
        <label>Bajan:</label>
        <input type="number" name="bajan" value="<?php echo e($gps->bajan); ?>"><br><br>
        <label>Linea:</label>
        <input type="text" name="linea" value="<?php echo e($gps->linea); ?>"><br><br>
        <button type="submit">Submit</button>
    </form>
    <a href="<?php echo e(route('gps.index')); ?>">Back</a>
</body>
</html>
<?php /**PATH D:\UAGRM\8 Octavo Semestre\Sistemas de Información Geográfica\Proyecto 1-2024\gps\GPS\resources\views/gps/edit.blade.php ENDPATH**/ ?>