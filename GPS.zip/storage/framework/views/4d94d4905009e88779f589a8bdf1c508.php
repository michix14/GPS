<!-- resources/views/gps/index.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>GPS Data</title>
</head>
<body>
    <h1>GPS Data</h1>
    <a href="<?php echo e(route('gps.create')); ?>">Add New GPS Data</a>
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Latitude</th>
                <th>Longitude</th>
                <th>Placa</th>
                <th>Suben</th>
                <th>Bajan</th>
                <th>Linea</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $gpsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($gps->id); ?></td>
                    <td><?php echo e($gps->latitude); ?></td>
                    <td><?php echo e($gps->longitude); ?></td>
                    <td><?php echo e($gps->placa); ?></td>
                    <td><?php echo e($gps->suben); ?></td>
                    <td><?php echo e($gps->bajan); ?></td>
                    <td><?php echo e($gps->linea); ?></td>
                    <td>
                        <a href="<?php echo e(route('gps.show', $gps->id)); ?>">View</a>
                        <a href="<?php echo e(route('gps.edit', $gps->id)); ?>">Edit</a>
                        <form action="<?php echo e(route('gps.destroy', $gps->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH D:\UAGRM\8 Octavo Semestre\Sistemas de Información Geográfica\Proyecto 1-2024\gps\resources\views/gps/index.blade.php ENDPATH**/ ?>